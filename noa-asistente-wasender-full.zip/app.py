import os, json, glob, re
from flask import Flask, request, jsonify
from dotenv import load_dotenv
import requests
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from rapidfuzz import fuzz

load_dotenv()

W_URL = os.getenv("WASENDER_BASE_URL", "https://wasenderapi.com/api/send-message")
W_TOKEN = os.getenv("WASENDER_TOKEN")
OWNER = os.getenv("OWNER_PHONE")
PORT = int(os.getenv("PORT", "5000"))

app = Flask(__name__)

IDENTIDAD = "Soy Noa IA, el gemelo digital de Tony. Respondo claro, breve y aplicable."

def load_kb_texts():
    chunks = []
    for path in glob.glob("kb/*.md") + glob.glob("kb/*.txt"):
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        parts = re.split(r"\n\s*\n", text)
        for p in parts:
            if p.strip():
                chunks.append({"source": os.path.basename(path), "text": p.strip()})
    qna_path = "kb/qna.json"
    if os.path.exists(qna_path):
        try:
            with open(qna_path, "r", encoding="utf-8") as f:
                qna = json.load(f)
            for item in qna:
                if isinstance(item, dict) and "q" in item and "a" in item:
                    chunks.append({"source": "qna.json", "text": f"Q: {item['q']}\nA: {item['a']}"})
        except Exception:
            pass
    return chunks

KB = load_kb_texts()
VECTORIZER = TfidfVectorizer(ngram_range=(1,2), min_df=1)
DOCS = [c["text"] for c in KB] if KB else ["(vacío)"]
TFIDF = VECTORIZER.fit_transform(DOCS)

def retrieve(query, k=5):
    if not KB:
        return []
    q_vec = VECTORIZER.transform([query])
    sims = cosine_similarity(q_vec, TFIDF).flatten()
    idxs = sims.argsort()[::-1][:k]
    results = []
    for i in idxs:
        results.append({**KB[i], "score": float(sims[i])})
    for r in results:
        r["score"] += 0.05 * (fuzz.partial_ratio(query, r["text"]) / 100.0)
    return sorted(results, key=lambda x: x["score"], reverse=True)

def draft_answer(query):
    top = retrieve(query, k=4)
    if not top:
        return ("Todavía no tengo notas en mi /kb. "
                "Decime qué archivo querés que agregue (md/txt/json) y lo aprendo.")
    bullets = []
    for t in top:
        lines = [ln.strip("-•> ") for ln in t["text"].splitlines() if ln.strip()]
        bullets.extend(lines[:2])
    bullets = bullets[:6] if bullets else ["No tengo suficiente contexto en /kb."]
    return f"{IDENTIDAD}\nPregunta: {query}\n\nRespuesta concreta:\n• " + "\n• ".join(bullets)

def send_text(to, message):
    if not (W_URL and W_TOKEN):
        return False
    headers = {"Authorization": f"Bearer {W_TOKEN}", "Content-Type": "application/json"}
    payload = {"to": to, "text": message}
    try:
        r = requests.post(W_URL, headers=headers, json=payload, timeout=20)
        print("Wasender resp:", r.status_code, r.text)
        return r.ok
    except Exception as e:
        print("Error Wasender:", e)
        return False

@app.route("/webhook", methods=["POST"])
def webhook():
    data = request.get_json(force=True, silent=True) or {}
    from_number = str(data.get("from") or data.get("sender") or "").strip()
    text = (data.get("message") or data.get("text") or "").strip()

    if not from_number or not text:
        return jsonify({"ok": True, "skip": "no text"}), 200

    if OWNER and not from_number.endswith(OWNER[-8:]):
        return jsonify({"ok": True, "skip": "not owner"}), 200

    tlow = text.lower().strip()

    if tlow in ["ping", "hola", "noa", "help"]:
        send_text(from_number, "Aquí Noa 🤖. Preguntame de backend/frontend.\nComandos: 'recargar kb', 'status kb'.")
        return jsonify({"ok": True}), 200

    if tlow.startswith("recargar kb"):
        global KB, VECTORIZER, TFIDF, DOCS
        KB = load_kb_texts()
        DOCS = [c["text"] for c in KB] if KB else ["(vacío)"]
        VECTORIZER = TfidfVectorizer(ngram_range=(1,2), min_df=1)
        TFIDF = VECTORIZER.fit_transform(DOCS)
        send_text(from_number, f"✅ KB recargada. Docs: {len(KB)} fragmentos.")
        return jsonify({"ok": True}), 200

    if tlow.startswith("status kb"):
        send_text(from_number, f"Tengo {len(KB)} fragmentos en memoria local (/kb).")
        return jsonify({"ok": True}), 200

    answer = draft_answer(text)
    if len(answer) > 3500:
        answer = answer[:3400] + "\n\n(…recortado)"
    send_text(from_number, answer)
    return jsonify({"ok": True}), 200

@app.get("/")
def health():
    return "Noa-Asistente (Bearer) OK 🚀", 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT)
