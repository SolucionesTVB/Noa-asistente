# Frontend – Guías
- `npm install`
- `npm run dev`
- `npm run build` → `dist/`
- Deploy rápido: Netlify o GitHub Pages
