# Backend – Notas rápidas

## Entornos
- Crear venv: `python -m venv .venv && source .venv/bin/activate`
- Instalar: `pip install -r requirements.txt`
- Dev: `python app.py`  | Prod: `gunicorn app:app`

## Render
- Build: `pip install -r requirements.txt`
- Start: `gunicorn app:app`
- Env: WASENDER_BASE_URL, WASENDER_TOKEN, OWNER_PHONE, PORT
- Logs: panel de Render

## Endpoints
- GET `/` → health
- POST `/webhook` → mensajes entrantes (Wasender)
