# Comandos útiles
## Python
- `python -m venv .venv`
- `source .venv/bin/activate`
- `pip install -r requirements.txt`
- `python app.py`
- `gunicorn app:app`

## Git
- `git add . && git commit -m "mensaje"`
- `git push origin main`

## Render
- Build: `pip install -r requirements.txt`
- Start: `gunicorn app:app`
