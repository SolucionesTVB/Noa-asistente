# Noa Asistente (WhatsApp + Wasender)

Proyecto limpio para desplegar en Render y conectar a WasenderAPI (Bearer Token).

## Pasos rápidos
1. Crear repo `noa-asistente` en GitHub y subir este contenido.
2. Render → New Web Service → conectar repo.
3. Build: `pip install -r requirements.txt`
   Start: `gunicorn app:app`
4. Variables de entorno en Render:
   - WASENDER_BASE_URL = https://wasenderapi.com/api/send-message
   - WASENDER_TOKEN = (tu token de **Your API Key** en la sesión Noa Asistente)
   - OWNER_PHONE = +506TU_NUMERO
   - PORT = 5000
5. En Wasender → Webhook URL: `https://TU-APP.onrender.com/webhook` (POST).
6. En WhatsApp: `hola`, `recargar kb`, `status kb`.
